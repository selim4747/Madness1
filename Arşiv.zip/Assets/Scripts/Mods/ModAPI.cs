using System;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Madness.Mods
{
    /// <summary>
    /// Mono derlemede DLL modlarının kullanabileceği tam yetkili API.
    /// IL2CPP'de DLL yüklenmediği için bu sınıf da sadece Mono modlarından çağrılır.
    /// </summary>
    public static class ModAPI
    {
        public static bool IsFullPower => !ModScriptLoader.IsIL2CPP;

        // --- Event Bus ---
        public static void Subscribe<T>(Action<T> handler, int priority = 0, string owner = "") where T : ModContext
            => ModEventBus.Subscribe(handler, priority, owner);

        public static void UnsubscribeOwner(string owner)
            => ModEventBus.UnsubscribeOwner(owner);

        // --- Content ---
        public static void RegisterContent(string owner, string id, UnityEngine.Object asset)
            => ModContentOverride.Register(owner, id, asset);

        public static void RegisterContent(string id, UnityEngine.Object asset)
            => ModContentOverride.Register(id, asset);

        public static T GetContent<T>(string id, T fallback = null) where T : UnityEngine.Object
            => ModContentOverride.GetOrDefault(id, fallback);

        /// <summary>
        /// Mod Creator ile eklenen yeni içeriği veya başka bir içeriğin override'ını getirir.
        /// Önce override, sonra yeni içerik registry'si, en son fallback denenir.
        /// </summary>
        public static T GetModContent<T>(string id, T fallback = null) where T : UnityEngine.Object
        {
            T overrideAsset;
            if (ModContentOverride.TryGet(id, out overrideAsset)) return overrideAsset;
            T registered;
            return ModContentRegistry.TryGet(id, out registered) ? registered : fallback;
        }

        public static bool TryGetRegisteredContent<T>(string id, out T asset) where T : UnityEngine.Object
            => ModContentRegistry.TryGet(id, out asset);

        public static T LoadAsset<T>(string modId, string assetName) where T : UnityEngine.Object
            => ModAssetLoader.LoadAsset<T>(modId, assetName);

        // --- Scenes ---
        public static bool LoadModScene(string modId, string sceneName = null, bool additive = false)
            => ModSceneLoader.LoadFromMod(modId, sceneName, additive);

        public static void LoadScene(string sceneName, bool additive = false)
            => SceneManager.LoadScene(sceneName, additive ? LoadSceneMode.Additive : LoadSceneMode.Single);

        // --- Save ---
        public static void SetState(string modId, string json, int schema = 1)
            => ModRuntime.EnsureExists().SetState(modId, json, schema);

        public static string GetState(string modId)
            => ModRuntime.EnsureExists().GetState(modId);

        // --- Panel ayarları (save'den bağımsız) ---
        public static string GetSetting(string modId, string key, string fallback = "")
            => ModSettingsStore.Get(modId, key, fallback);

        public static bool GetSettingBool(string modId, string key, bool fallback = false)
            => ModSettingsStore.GetBool(modId, key, fallback);

        public static float GetSettingFloat(string modId, string key, float fallback = 0f)
            => ModSettingsStore.GetFloat(modId, key, fallback);

        public static void SetSetting(string modId, string key, string value)
            => ModSettingsStore.Set(modId, key, value);

        // --- World ---
        public static bool TryGetAnchor(string id, out Vector3 position)
            => ModWorldRegistry.TryGetPosition(id, out position);

        // --- Utility ---
        public static void Log(string modId, string message)
            => Debug.Log("[" + modId + "] " + message);

        public static void LogError(string modId, string message)
            => Debug.LogError("[" + modId + "] " + message);

        /// <summary>
        /// Mono'da true döner. Modlar buna bakarak "tam güç" özelliklerini açabilir.
        /// </summary>
        public static bool CanRunArbitraryCode => IsFullPower;
    }
}
