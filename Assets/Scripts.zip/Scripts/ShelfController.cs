﻿using UnityEngine;
using TMPro;
using System;
using UnityEngine.UI;

public class ShelfController : MonoBehaviour
{
    [Header("Rafın İçeriği")]
    public BookData raftakiKitap;

    [Header("Arayüz (UI) Ayarları")]
    public GameObject rafBilgiPaneli;
    public TextMeshProUGUI rafBilgiYazisi;

    [Header("Öğrenci Talebi — Parlama Efekti")]
    [Tooltip("Bir öğrenci bu raftaki kitabı istediğinde aktif/pasif olacak obje (örn. sarı ışık/outline).")]
    [SerializeField] private GameObject glowVisual;

    private bool oyuncuYakin = false;

    // ==================================================
    // GLOBAL SİSTEM ÖZELLİKLERİ
    // ==================================================

    public Action<BookData> OnFirstDiscovered;

    public BookData book
    {
        get { return raftakiKitap; }
        set { raftakiKitap = value; }
    }

    // Kasa'dan güncel stoğu saniye saniye çeken sistem
    public int CurrentStock
    {
        get
        {
            if (KasaEtkilesim.Instance != null && raftakiKitap != null && KasaEtkilesim.Instance.kitapStoklari.ContainsKey(raftakiKitap))
                return KasaEtkilesim.Instance.kitapStoklari[raftakiKitap];
            return 0;
        }
    }

    public bool HasStock { get { return CurrentStock > 0; } }
    public const int MaxStock = 15;
    public bool isUnlocked { get { return gameObject.activeInHierarchy; } }
    public Vector3 ApproachPosition { get { return this.transform.position; } }

    public void Unlock() { gameObject.SetActive(true); }

    /// <summary>Öğrenci bu raftaki kitabı istediğinde çağrılır (parlama efekti).</summary>
    public void SetGlow(bool isGlowing)
    {
        if (glowVisual != null) glowVisual.SetActive(isGlowing);
    }

    /// <summary>Öğrenci kitabı geri koyduğunda (teslimattan sonra ya da zaman aşımında) çağrılır — stoğu 1 artırır.</summary>
    public void ReturnOne()
    {
        if (KasaEtkilesim.Instance == null || raftakiKitap == null) return;

        if (!KasaEtkilesim.Instance.kitapStoklari.ContainsKey(raftakiKitap))
            KasaEtkilesim.Instance.kitapStoklari[raftakiKitap] = 0;

        KasaEtkilesim.Instance.kitapStoklari[raftakiKitap] += 1;
    }

    /// <summary>Raftan bir kitap alınır — stoğu 1 azaltır. Stok yoksa null döner.</summary>
    public BookData TryTakeOne()
    {
        if (!HasStock) return null;

        if (KasaEtkilesim.Instance != null && KasaEtkilesim.Instance.kitapStoklari.ContainsKey(raftakiKitap))
            KasaEtkilesim.Instance.kitapStoklari[raftakiKitap] -= 1;

        return raftakiKitap;
    }

    public void KitapAta(BookData yeniKitap)
    {
        raftakiKitap = yeniKitap;
        OnFirstDiscovered?.Invoke(raftakiKitap);
    }

    public void MenuyuAcKapat()
    {
        if (oyuncuYakin && rafBilgiPaneli != null)
        {
            rafBilgiPaneli.SetActive(!rafBilgiPaneli.activeSelf);
            if (rafBilgiPaneli.activeSelf && raftakiKitap != null)
            {
                // PATRONUN İSTEĞİ: Stok miktarı artık ekranda yeşil yeşil parlıyor!
                rafBilgiYazisi.text = $"<color=yellow>{raftakiKitap.kitapAdi}</color>\n" +
                                      $"<color=#00ff00><b>Stok Miktarı: {CurrentStock} Adet</b></color>\n" +
                                      $"Tür: {raftakiKitap.kitapTuru}\n" +
                                      $"Nadirlik: {raftakiKitap.nadirlik}\n" +
                                      $"Fiyat: {raftakiKitap.fiyat} Altın\n\n" +
                                      $"<i>{raftakiKitap.loreBilgisi}</i>";
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            oyuncuYakin = true;
            if (PlayerInteraction.Instance != null) PlayerInteraction.Instance.RegisterInfoShelf(this);
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            oyuncuYakin = false;
            if (rafBilgiPaneli != null) rafBilgiPaneli.SetActive(false);

            if (PlayerInteraction.Instance != null) PlayerInteraction.Instance.UnregisterInfoShelf(this);
        }
    }

    private void OnDisable()
    {
        // Raf havuza donerken/deaktif olurken kayitli kalmasin
        if (PlayerInteraction.Instance != null) PlayerInteraction.Instance.UnregisterInfoShelf(this);
    }

    // NOT: PC klavye kısayolu (E tuşu) kaldırıldı — Input System paketine geçince
    // eski UnityEngine.Input çağrıları InvalidOperationException fırlatıyordu.
    // Gerçek açma/kapama zaten PlayerInteraction'ın tek etkileşim zincirinden çalışıyor.
}