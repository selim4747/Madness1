// SadikMusteriYoneticisi.cs — Musteri-Oyuncu ILISKI puani takip eder. Oyuncu bir musteriyle
// KONUSTUKCA (diyalog), o musterinin dukkana TEKRAR GELME SANSI artar. Belirli bir puana
// ulasinca "mudavim" olur.
//
// COK KARAKTER OLCEKLENIR: her karakter ScriptableObject asset'i olarak degil, KENDI ISMI
// (musteriIsmi) ile bir STRING anahtarli sozlukte takip edilir — yani onceden hicbir yerde
// kayitli olmasi gerekmez, kac karakter eklersen ekle otomatik calisir.
//
// NJG Games | Delilik | Unity 6 | UTF-8 with BOM
using UnityEngine;
using System;
using System.Collections.Generic;

public class SadikMusteriYoneticisi : MonoBehaviour
{
    public static SadikMusteriYoneticisi Instance { get; private set; }

    [Header("İlişki Puanı Kazanımı")]
    [Tooltip("Her SOHBET (diyalog) puani ne kadar iliski puani kazandirir.")]
    [SerializeField] private int sohbetPuani = 5;

    [Header("Müdavim Eşiği")]
    [Tooltip("Bu puana ulasan musteri 'mudavim' sayilir.")]
    [SerializeField] private int mudavimEsigi = 30;

    [Header("Gelme Şansı Ağırlığı")]
    [Tooltip("Iliski puani basina, o karakterin SECILME agirligina eklenecek yuzde. Orn: 0.02 = her puan +%2 agirlik. 20 puanlik biri, hic konusulmamis birine gore %40 daha olasi secilir.")]
    [SerializeField] private float puanBasiAgirlikCarpani = 0.02f;

    [Tooltip("Bir karakterin agirligi ne kadar buyurse buyusun, en fazla bu katina kadar cikabilir (asiri baskinlik olmasin diye guvenlik siniri).")]
    [SerializeField] private float maxAgirlikCarpani = 4f;

    /// <summary>Bir musteri MUDAVIM olunca tetiklenir (UI/kutlama icin).</summary>
    public event Action<string> OnMudavimOldu;

    private readonly Dictionary<string, int> iliskiPuanlari = new Dictionary<string, int>();

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    public int GetIliskiPuani(string musteriIsmi)
    {
        if (string.IsNullOrEmpty(musteriIsmi)) return 0;
        int puan;
        return iliskiPuanlari.TryGetValue(musteriIsmi, out puan) ? puan : 0;
    }

    public bool MudavimMi(string musteriIsmi)
    {
        return GetIliskiPuani(musteriIsmi) >= mudavimEsigi;
    }

    /// <summary>MusteriSohbetRadari.SohbetEt() GERCEKTEN bir diyalog gosterdiginde cagirir.</summary>
    public void SohbetEdildi(string musteriIsmi)
    {
        PuanEkle(musteriIsmi, sohbetPuani);
    }

    private void PuanEkle(string musteriIsmi, int miktar)
    {
        if (string.IsNullOrEmpty(musteriIsmi) || miktar == 0) return;

        bool oncedenMudavimMiydi = MudavimMi(musteriIsmi);

        if (!iliskiPuanlari.ContainsKey(musteriIsmi)) iliskiPuanlari[musteriIsmi] = 0;
        iliskiPuanlari[musteriIsmi] = Mathf.Max(0, iliskiPuanlari[musteriIsmi] + miktar);

        // DEBUG: her puan kazanimini Console'a yazdir — SadikMusteriYoneticisi baglaninca
        // puanlarin gercekten islendigini gormek icin. Musdavim esigine ne kadar kaldigini
        // da gosterir, boylece 30 puana ulasmayi beklemeden ilerlemeyi takip edebilirsin.
        Debug.Log($"💛 [İLİŞKİ] {musteriIsmi}: +{miktar} puan (toplam: {iliskiPuanlari[musteriIsmi]} / {mudavimEsigi})");

        if (!oncedenMudavimMiydi && MudavimMi(musteriIsmi))
        {
            PlayerProgressStats.AddRegularCustomer();
            OnMudavimOldu?.Invoke(musteriIsmi);
            if (ToastNotification.Instance != null)
                ToastNotification.Instance.Show(musteriIsmi + " artık müdavim müşterin! Daha sık uğrayacak.", 3.5f);
        }
    }

    /// <summary>Bu karakterin SECILME agirligi carpani. 1.0 = normal (hic iliski yok).
    /// CustomerController karakter secerken, uniform rastgele yerine BUNUNLA agirlikli secer.</summary>
    public float GetSecimAgirligi(string musteriIsmi)
    {
        int puan = GetIliskiPuani(musteriIsmi);
        float carpan = 1f + (puan * puanBasiAgirlikCarpani);
        return Mathf.Min(carpan, maxAgirlikCarpani);
    }

    /// <summary>Agirlikli rastgele secim — cok sayida karakter icin de dogrusal (O(n)) calisir,
    /// performans sorunu olmaz. CustomerController.Baslat() bunu kullanir.</summary>
    public NPCKimligi AgirlikliSec(List<NPCKimligi> adaylar)
    {
        if (adaylar == null || adaylar.Count == 0) return null;
        if (adaylar.Count == 1) return adaylar[0];

        float toplamAgirlik = 0f;
        for (int i = 0; i < adaylar.Count; i++)
        {
            if (adaylar[i] == null) continue;
            toplamAgirlik += GetSecimAgirligi(adaylar[i].musteriIsmi);
        }

        if (toplamAgirlik <= 0f) return adaylar[UnityEngine.Random.Range(0, adaylar.Count)];

        float rastgeleNokta = UnityEngine.Random.Range(0f, toplamAgirlik);
        float birikmis = 0f;

        for (int i = 0; i < adaylar.Count; i++)
        {
            if (adaylar[i] == null) continue;
            birikmis += GetSecimAgirligi(adaylar[i].musteriIsmi);
            if (rastgeleNokta <= birikmis) return adaylar[i];
        }

        return adaylar[adaylar.Count - 1]; // guvenlik yedegi (float yuvarlama payi icin)
    }

    // ── Kayit koprusu ──

    public void ApplySave(SaveData data)
    {
        iliskiPuanlari.Clear();
        if (data.musteriIliskileri == null) return;

        for (int i = 0; i < data.musteriIliskileri.Count; i++)
        {
            IliskiKaydi kayit = data.musteriIliskileri[i];
            if (kayit != null && !string.IsNullOrEmpty(kayit.isim))
                iliskiPuanlari[kayit.isim] = kayit.puan;
        }
    }

    public void WriteToSave(SaveData data)
    {
        data.musteriIliskileri.Clear();
        foreach (KeyValuePair<string, int> kv in iliskiPuanlari)
        {
            IliskiKaydi kayit = new IliskiKaydi();
            kayit.isim = kv.Key;
            kayit.puan = kv.Value;
            data.musteriIliskileri.Add(kayit);
        }
    }
}

[Serializable]
public class IliskiKaydi
{
    public string isim;
    public int puan;
}