﻿// MusteriSohbetRadari.cs — SADECE MAGAZA (dukkan icinde yururken) sohbeti icin. Bahce
// sohbeti artik BahceSohbetRadari'ye tasindi — bu script bahcedeyken KENDINI KAYIT ETMEZ.
// NJG Games | Delilik | Unity 6 | UTF-8 with BOM
using UnityEngine;
using System.Collections.Generic;

public class MusteriSohbetRadari : MonoBehaviour, ISohbetHedefi
{
    private NPCKimligi musteriKimligi;
    private CustomerController musteriScripti;

    public Transform SohbetTransformuAl() { return transform; }

    public void SohbetEt()
    {
        musteriScripti = GetComponentInParent<CustomerController>();
        if (musteriScripti != null) musteriKimligi = musteriScripti.SecilenKimlik;
        if (musteriKimligi == null) return;

        // MAGAZA disinda (bahcedeyse) bu radar hic konusmaz — o is BahceSohbetRadari'de.
        if (musteriScripti.BahcedeMi) return;

        List<string> havuz = musteriKimligi.ozelDiyaloglar;
        if (havuz == null || havuz.Count == 0) return;

        // OZEL KITAP OKUNDUKTAN SONRA: bu kisi kendi kisiye ozel kitabini satin aldiysa,
        // kitapla ilgili ekstra satirlar KALICI olarak normal havuza eklenir.
        List<string> ekDiyaloglar = OzelKitapDiyaloglariYoneticisi.Instance != null
            ? OzelKitapDiyaloglariYoneticisi.Instance.EkDiyaloglariAl(musteriKimligi.musteriIsmi)
            : null;

        List<string> tamHavuz = havuz;
        if (ekDiyaloglar != null && ekDiyaloglar.Count > 0)
        {
            tamHavuz = new List<string>(havuz);
            tamHavuz.AddRange(ekDiyaloglar);
        }

        if (!MusteriKonusmaSinirlayici.YeniLafAlabilirMi(musteriKimligi)) return;

        string secilenLaf = tamHavuz[Random.Range(0, tamHavuz.Count)];

        DialogueLine satir = new DialogueLine();
        satir.speakerName = musteriKimligi.musteriIsmi;
        satir.text = secilenLaf;

        List<DialogueLine> sohbet = new List<DialogueLine> { satir };
        MusteriKonusmaSinirlayici.LafVerildi(musteriKimligi);

        if (SadikMusteriYoneticisi.Instance != null)
            SadikMusteriYoneticisi.Instance.SohbetEdildi(musteriKimligi.musteriIsmi);

        if (DialogueBox.Instance != null) DialogueBox.Instance.Show(sohbet);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player") || PlayerInteraction.Instance == null) return;

        // Bahcedeyken bu radar KAYDOLMAZ — BahceSohbetRadari devreye girer.
        CustomerController c = GetComponentInParent<CustomerController>();
        if (c != null && c.BahcedeMi) return;

        PlayerInteraction.Instance.RegisterChatTarget(this);
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player") && PlayerInteraction.Instance != null)
            PlayerInteraction.Instance.UnregisterChatTarget(this);
    }

    private void OnDisable()
    {
        if (PlayerInteraction.Instance != null)
            PlayerInteraction.Instance.UnregisterChatTarget(this);
    }
}