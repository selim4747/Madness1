﻿// OzelMusteriHikayesiYoneticisi.cs — Var olan DUZENLI musterilerden BELIRLI birine, normal
// sohbetin YERINE GECEN, dallanan (secmeli) TEK SEFERLIK bir hikaye anlatir. Hikaye
// Konugu'ndan (HikayeKonuguYoneticisi) farki: yeni bir NPC/prefab gerektirmez — zaten
// dukkana gelen bir musterinin USTUNE bindirilir.
//
// MusteriSohbetRadari, normal rastgele laf secmeden ONCE burayi kontrol eder: bu musterinin
// BITMEMIS bir ozel hikayesi varsa, ONUN YERINE bu gosterilir. Secenek secilince (DialogueBox.
// SecenekliGoster'in callback'i) otomatik olarak SONRAKI cumleye geçilir — oyuncu sadece
// secenek butonlarina basarak ilerler, ETK'ye tekrar basmasi gerekmez. Secenegi olmayan bir
// cumleye ulasilinca hikaye TAMAMLANMIS sayilir, bir daha tetiklenmez.
//
// NJG Games | Delilik | Unity 6 | UTF-8 with BOM
using UnityEngine;
using System.Collections.Generic;

public class OzelMusteriHikayesiYoneticisi : MonoBehaviour
{
    public static OzelMusteriHikayesiYoneticisi Instance { get; private set; }

    [Header("Hikayeler")]
    [SerializeField] private List<OzelMusteriHikayesiVerisi> hikayeler = new List<OzelMusteriHikayesiVerisi>();

    // musteriIsmi -> o an konusmanin hangi cumlede oldugu (henuz bitmemis konusmalar icin)
    private readonly Dictionary<string, string> aktifKonum = new Dictionary<string, string>();

    // Tamamlanmis hikayelerin id'leri (kayittan gelir/kayda gider)
    private readonly HashSet<string> tamamlananHikayeler = new HashSet<string>();

    private Dictionary<string, OzelMusteriHikayesiVerisi> isimHaritasi;

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;

        isimHaritasi = new Dictionary<string, OzelMusteriHikayesiVerisi>();
        if (hikayeler != null)
        {
            for (int i = 0; i < hikayeler.Count; i++)
            {
                OzelMusteriHikayesiVerisi h = hikayeler[i];
                if (h != null && !string.IsNullOrEmpty(h.hedefMusteriIsmi) && !isimHaritasi.ContainsKey(h.hedefMusteriIsmi))
                    isimHaritasi[h.hedefMusteriIsmi] = h;
            }
        }
    }

    /// <summary>Bu musteride, HENUZ TAMAMLANMAMIS bir ozel hikaye var mi?
    /// MusteriSohbetRadari, normal lafindan ONCE bunu kontrol eder.</summary>
    public bool OzelHikayeVarMi(string musteriIsmi)
    {
        if (string.IsNullOrEmpty(musteriIsmi)) return false;

        OzelMusteriHikayesiVerisi hikaye;
        if (!isimHaritasi.TryGetValue(musteriIsmi, out hikaye)) return false;

        return !tamamlananHikayeler.Contains(hikaye.hikayeId);
    }

    /// <summary>Hikayeyi baslatir/devam ettirir — DialogueBox'ta secmeli olarak gosterir.
    /// speakerIsmi, panelde konusan adi olarak kullanilir (genelde musterinin kendi ismi).</summary>
    public void HikayeyiGoster(string musteriIsmi, string speakerIsmi)
    {
        OzelMusteriHikayesiVerisi hikaye;
        if (!isimHaritasi.TryGetValue(musteriIsmi, out hikaye)) return;

        string mevcutId;
        if (!aktifKonum.TryGetValue(musteriIsmi, out mevcutId) || string.IsNullOrEmpty(mevcutId))
            mevcutId = hikaye.baslangicCumleId;

        OzelHikayeCumlesi cumle = CumleyiBul(hikaye, mevcutId);
        if (cumle == null) return;

        GosterVeBekle(hikaye, cumle, musteriIsmi, speakerIsmi);
    }

    private OzelHikayeCumlesi CumleyiBul(OzelMusteriHikayesiVerisi hikaye, string id)
    {
        if (hikaye.cumleler == null) return null;
        for (int i = 0; i < hikaye.cumleler.Count; i++)
            if (hikaye.cumleler[i] != null && hikaye.cumleler[i].id == id) return hikaye.cumleler[i];
        return null;
    }

    private void GosterVeBekle(OzelMusteriHikayesiVerisi hikaye, OzelHikayeCumlesi cumle, string musteriIsmi, string speakerIsmi)
    {
        aktifKonum[musteriIsmi] = cumle.id;

        bool secenekVarMi = cumle.secenekler != null && cumle.secenekler.Count > 0;

        // YAPRAK: hikaye burada biter — bir daha OzelHikayeVarMi() true donmez.
        if (!secenekVarMi) TamamlandiOlarakIsaretle(hikaye, musteriIsmi);

        List<string> secenekMetinleri = new List<string>();
        if (secenekVarMi)
        {
            for (int i = 0; i < cumle.secenekler.Count; i++)
                secenekMetinleri.Add(cumle.secenekler[i].secenekMetni);
        }

        if (DialogueBox.Instance == null) return;

        DialogueBox.Instance.SecenekliGoster(speakerIsmi, cumle.metin, secenekMetinleri, (secilenIndex) =>
        {
            if (!secenekVarMi) return; // guvenlik — secenek yoksa zaten cagrilmaz
            if (secilenIndex < 0 || secilenIndex >= cumle.secenekler.Count) return;

            string hedefId = cumle.secenekler[secilenIndex].hedefCumleId;
            OzelHikayeCumlesi hedefCumle = CumleyiBul(hikaye, hedefId);
            if (hedefCumle == null) return;

            GosterVeBekle(hikaye, hedefCumle, musteriIsmi, speakerIsmi);
        });
    }

    private void TamamlandiOlarakIsaretle(OzelMusteriHikayesiVerisi hikaye, string musteriIsmi)
    {
        tamamlananHikayeler.Add(hikaye.hikayeId);
        aktifKonum.Remove(musteriIsmi);
    }

    // ── Kayit koprusu ──

    public void ApplySave(SaveData data)
    {
        tamamlananHikayeler.Clear();
        if (data.tamamlananOzelHikayeler != null)
            for (int i = 0; i < data.tamamlananOzelHikayeler.Count; i++)
                tamamlananHikayeler.Add(data.tamamlananOzelHikayeler[i]);
    }

    public void WriteToSave(SaveData data)
    {
        data.tamamlananOzelHikayeler.Clear();
        foreach (string id in tamamlananHikayeler) data.tamamlananOzelHikayeler.Add(id);
    }
}
