// BahceSohbetRadari.cs — Musteriye DEGIL, MASAYA baglidir. Oyuncu ETK'ye basinca, o masada
// oturan musteriyle SECIMLI bir konusma baslatir: NPC bir cumle soyler, DialogueBox'ta
// secenek butonlari belirir, oyuncu birini secer, NPC secime gore devam eder. Seceneksiz
// bir cumleye ulasilinca (ya da oyuncu Kapat'a basinca) konusma biter.
// NJG Games | Delilik | Unity 6 | UTF-8 with BOM
using UnityEngine;
using System.Collections.Generic;

public class BahceSohbetRadari : MonoBehaviour, ISohbetHedefi
{
    [Tooltip("Bu buyuk masanin ETRAFINDAKI TUM oturma noktalari (orn. 8 nokta). BahceYoneticisi'nde her biri AYRI ayri takip edildigi icin, radar HANGISINDE oturan varsa (oyuncuya en yakin OLANI) onu bulur.")]
    [SerializeField] private Transform[] masaNoktalari;

    private CustomerController aktifMusteri;
    private NPCKimligi aktifKimlik;

    public Transform SohbetTransformuAl() { return transform; }

    /// <summary>masaNoktalari'ndaki TUM noktalari tarar, oturan biri olan noktalar arasindan
    /// RASTGELE birini secer (en yakin DEGIL) — boylece ETK'ye tekrar tekrar basinca hep
    /// ayni (en yakin) kisiyle degil, gruptaki FARKLI kisilerle konusma sansi olur.</summary>
    private CustomerController RastgeleOturaniBul()
    {
        if (masaNoktalari == null || masaNoktalari.Length == 0 || BahceYoneticisi.Instance == null) return null;

        List<CustomerController> oturanlar = new List<CustomerController>();
        foreach (Transform nokta in masaNoktalari)
        {
            if (nokta == null) continue;
            CustomerController oturan = BahceYoneticisi.Instance.GetOturan(nokta);
            if (oturan != null) oturanlar.Add(oturan);
        }

        return oturanlar.Count > 0 ? oturanlar[Random.Range(0, oturanlar.Count)] : null;
    }

    public void SohbetEt()
    {
        if (BahceYoneticisi.Instance == null || BahceSohbetYoneticisi.Instance == null || DialogueBox.Instance == null)
        {
            Debug.LogWarning($"🔴 [BAHÇE SOHBET] Eksik referans — BahceYoneticisi={(BahceYoneticisi.Instance == null ? "YOK" : "var")}, BahceSohbetYoneticisi={(BahceSohbetYoneticisi.Instance == null ? "YOK" : "var")}, DialogueBox={(DialogueBox.Instance == null ? "YOK" : "var")}");
            return;
        }

        aktifMusteri = RastgeleOturaniBul();
        if (aktifMusteri == null)
        {
            Debug.LogWarning($"🔴 [BAHÇE SOHBET] {masaNoktalari.Length} noktanın hiçbirinde kimse oturmuyor.");
            return;
        }

        aktifKimlik = aktifMusteri.SecilenKimlik;
        if (aktifKimlik == null)
        {
            Debug.LogWarning($"🔴 [BAHÇE SOHBET] {aktifMusteri.name} oturuyor ama SecilenKimlik null.");
            return;
        }

        // NOT: MusteriKonusmaSinirlayici (gunluk konusma limiti) BILEREK burada kontrol
        // EDILMIYOR — o sistem MAGAZA kucuk sohbeti icin tasarlandi (oyuncu yururken
        // rastgele bir kere konusur). Bahcede oyuncu AYNI kisiyle defalarca ETK'ye basip
        // konu agini kesfediyor — o limit hemen dolup "bugun epey konustuk" mesajina
        // takiliyordu. Bahcenin KENDI dogal siniri zaten var: sikilma sayaci (BahceSohbetiKaydet).
        BahceSohbetSonucu sonuc = BahceSohbetYoneticisi.Instance.SohbetiBaslat(aktifMusteri, aktifKimlik);
        Debug.Log($"🟢 [BAHÇE SOHBET] {aktifKimlik.musteriIsmi} ile sohbet başlatılıyor, sonuc={(sonuc == null ? "NULL" : "'" + sonuc.npcMetni + "'")}");
        SonucuGoster(sonuc);
    }

    /// <summary>Oyuncu bir secenek secince DialogueBox bunu cagirir.</summary>
    private void SecimYapildi(int index)
    {
        if (aktifMusteri == null || aktifKimlik == null || BahceSohbetYoneticisi.Instance == null) return;

        BahceSohbetSonucu sonuc = BahceSohbetYoneticisi.Instance.SecimYap(aktifMusteri, index, aktifKimlik);
        SonucuGoster(sonuc);
    }

    private void SonucuGoster(BahceSohbetSonucu sonuc)
    {
        if (sonuc == null || string.IsNullOrEmpty(sonuc.npcMetni))
        {
            DialogueBox.Instance.Close();
            return;
        }

        aktifMusteri.BahceSohbetiKaydet(); // sikilma sayaci — bahcenin kendi dogal siniri

        if (SadikMusteriYoneticisi.Instance != null)
            SadikMusteriYoneticisi.Instance.SohbetEdildi(aktifKimlik.musteriIsmi);

        // Secenek YOKSA (yaprak cumle) — DialogueBox otomatik olarak sadece "Kapat" gosterir,
        // secenek paneli hic acilmaz (SecenekliGoster bunu zaten boyle yonetir).
        DialogueBox.Instance.SecenekliGoster(aktifKimlik.musteriIsmi, sonuc.npcMetni, sonuc.secenekMetinleri, SecimYapildi);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player") && PlayerInteraction.Instance != null)
            PlayerInteraction.Instance.RegisterChatTarget(this);
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player") && PlayerInteraction.Instance != null)
            PlayerInteraction.Instance.UnregisterChatTarget(this);
    }

    private void OnDisable()
    {
        if (PlayerInteraction.Instance != null)
            PlayerInteraction.Instance.UnregisterChatTarget(this);
    }
}